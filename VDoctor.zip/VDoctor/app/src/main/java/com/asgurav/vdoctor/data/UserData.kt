package com.asgurav.vdoctor.data

import java.util.*

data class UserData(
    val name: String? = null,
    val email: String? = null,
    val phone: String? = null,
    val date: Date? = null,
    val appointments: Int? = null
)

