package com.asgurav.vdoctor.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso

class DoctorAdapter(private var queryData: MutableList<DocumentSnapshot>) : RecyclerView.Adapter<DoctorAdapter.ViewHolder>() {

    private val storageRef = FirebaseStorage.getInstance().reference

    var myListener : MyItemClickListener? = null

    interface MyItemClickListener{
        fun onBookButtonClicked(view: View, position: Int,doctorInfo:DocumentSnapshot)
    }

    fun setMyItemClickListener (listener : MyItemClickListener){
        this.myListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val docName: TextView = itemView.findViewById(R.id.doctorName)
        val spc: TextView = itemView.findViewById(R.id.spc)
        val docImage: ImageView = itemView.findViewById(R.id.doctorImage)
        private val bookButton : Button = itemView.findViewById(R.id.bookAppointment)
        init {
            bookButton.setOnClickListener {
                if (myListener != null){
                    myListener!!.onBookButtonClicked(it,adapterPosition,queryData[adapterPosition])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.fragment_doctor_tile,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = queryData[position]
        holder.docName.text = item["doctor_name"].toString()
        ("Speciality: "+item["spc"].toString()).also { holder.spc.text = it }

        storageRef.child("doctor_images/"+item["doctor_image"].toString()).downloadUrl.addOnSuccessListener {
            val url = it
            Picasso.get().load(url).into(holder.docImage)
        }.addOnFailureListener {
            Log.i("ERRoR","Image URL NOT FOUND")
        }
    }

    override fun getItemCount(): Int {
        return queryData.size
    }

    fun findFirst(p0:String):Int{
        val i = queryData.find { it["spc"].toString().lowercase() == p0.lowercase() }
        return if (i!=null){
            queryData.indexOf(i)
        } else {
            -1
        }
    }


}


