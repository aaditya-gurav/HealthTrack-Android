package com.asgurav.vdoctor.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso

class PharmacyAdapter(private var queryData: MutableList<DocumentSnapshot>) : RecyclerView.Adapter<PharmacyAdapter.ViewHolder>() {

    private val storageRef = FirebaseStorage.getInstance().reference

    var myListener : MyItemClickListener? = null

    interface MyItemClickListener{
        fun onGetDirection(view: View, position: Int,doctorInfo:DocumentSnapshot)
    }

    fun setMyItemClickListener (listener : MyItemClickListener){
        this.myListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val pharmaName: TextView = itemView.findViewById(R.id.pharmacy_name)
        val pharmaRating: TextView = itemView.findViewById(R.id.pharma_rating)
        val pharmaImage: ImageView = itemView.findViewById(R.id.pharmacy_image)
        private val bookButton : Button = itemView.findViewById(R.id.get_directions)
        init {
            bookButton.setOnClickListener {
                if (myListener != null){
                    myListener!!.onGetDirection(it,adapterPosition,queryData[adapterPosition])
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.fragment_pharmacy_tile,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = queryData[position]
        holder.pharmaName.text = item["pharma_name"].toString()
        ("Rating : "+item["pharma_rating"].toString()+"/5").also { holder.pharmaRating.text = it }

        storageRef.child("pharma_images/"+item["pharma_image"].toString()).downloadUrl.addOnSuccessListener {
            val url = it
            Picasso.get().load(url).into(holder.pharmaImage)
        }.addOnFailureListener {
            Log.i("ERRoR","Image URL NOT FOUND")
        }
    }

    override fun getItemCount(): Int {
        return queryData.size
    }

}