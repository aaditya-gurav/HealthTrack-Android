package com.asgurav.vdoctor.data

import java.util.*

data class AppointmentData(
    val doc_id: String? = null,
    val link: String? = null,
    val time: String? = null,
    val user_id: String? = null,
    val timestamp: Date? = null,
)
