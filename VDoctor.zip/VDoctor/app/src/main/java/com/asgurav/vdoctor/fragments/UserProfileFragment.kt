package com.asgurav.vdoctor.fragments

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.adapters.AppointmentAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UserProfileFragment : Fragment() {

    private lateinit var queryData : QuerySnapshot
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter : AppointmentAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_user_profile, container, false)
        val db = Firebase.firestore

        val uid = FirebaseAuth.getInstance().currentUser?.uid
        db.collection("user_data").document(uid.toString()).get()
            .addOnSuccessListener { result ->
               Log.i("TAG","Data Fetched")
                (result["name"].toString() + " !!!").also { view.findViewById<TextView>(R.id.user_name).text = it }
            }
            .addOnFailureListener { exception ->
                Log.w("ERROR", "Error getting documents.", exception)
            }

        view.findViewById<Button>(R.id.changePassButton).setOnClickListener {
            val uid2 = FirebaseAuth.getInstance().currentUser?.uid
            db.collection("user_data").document(uid2.toString()).get()
                .addOnSuccessListener { result ->
                    Log.i("TAG","Data Fetched")
                    val emailAddress = result["email"].toString()

                    Firebase.auth.sendPasswordResetEmail(emailAddress)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(context,"Please check your Email",Toast.LENGTH_SHORT).show()
                                Log.d(TAG, "Email sent.")
                            }
                        }
                }
                .addOnFailureListener { exception ->
                    Log.w("ERROR", "Error getting documents.", exception)
                }
        }

        createAptTiles(view)

        return view
    }

    private fun createAptTiles(view: View) {
        val db = Firebase.firestore
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        db.collection("appointment_data")
            .whereEqualTo("user_id",uid)
            .get()
            .addOnSuccessListener {
                queryData = it
                recyclerView = view.findViewById(R.id.userRecycler)
                recyclerView.layoutManager = LinearLayoutManager(context)
                adapter = AppointmentAdapter(queryData.documents)
                recyclerView.adapter = adapter
            }
            .addOnFailureListener { exception ->
                Log.i("Data", "Error getting documents: ", exception)
            }
    }
}