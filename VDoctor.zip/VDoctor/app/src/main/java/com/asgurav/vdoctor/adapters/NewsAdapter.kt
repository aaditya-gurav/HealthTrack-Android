package com.asgurav.vdoctor.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.data.Article
import com.squareup.picasso.Picasso



class NewsAdapter(private var newsList: List<Article>) : RecyclerView.Adapter<NewsAdapter.ViewHolder>(){

    var myListener : GoButtonClicked? = null

    interface GoButtonClicked{
        fun onGoButton(position: Int)
    }

    fun setMyItemClickListener (listener : GoButtonClicked){
        this.myListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val newsTitle: TextView = itemView.findViewById(R.id.newsTitle)
        val newsDesc: TextView = itemView.findViewById(R.id.newsDesc)
        val newsImage: ImageView = itemView.findViewById(R.id.newsImage)
        val button : Button = itemView.findViewById(R.id.goButton)
        init {
            button.setOnClickListener {
                if (myListener != null){
                    myListener!!.onGoButton(adapterPosition)
                }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.fragment_news,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val newsItem = newsList[position]
        holder.newsTitle.text = newsItem.title

        var lengthTitle = newsItem.title.length
        lengthTitle = if (lengthTitle>30) 30 else lengthTitle
        (newsItem.title.substring(0,lengthTitle-1)+"...").also {holder.newsTitle.text = it }

        var length = newsItem.description.length
        length = if (length>800) 800 else length
        (newsItem.description.substring(0,length-1)+"...").also {holder.newsDesc.text = it }
        Picasso.get().load(newsItem.urlToImage).into(holder.newsImage);

    }

    override fun getItemCount(): Int {
        return 20
    }
}