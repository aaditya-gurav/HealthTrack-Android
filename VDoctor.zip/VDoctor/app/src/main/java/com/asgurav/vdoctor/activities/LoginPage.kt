package com.asgurav.vdoctor.activities

import android.content.ContentValues.TAG
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.asgurav.vdoctor.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import android.widget.TextView


class LoginPage : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val userID = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.user_id)
        val pass = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.pass)

        val loginButton = findViewById<Button>(R.id.login_button)

        val registerButton = findViewById<TextView>(R.id.register_button)
        val forgotPass = findViewById<TextView>(R.id.forgotPass)

        forgotPass.setOnClickListener { sendRestLink(userID.editText!!.text.toString()) }
        loginButton.setOnClickListener{signIn(userID.editText,pass.editText)}
        registerButton.setOnClickListener{registerUser()}
        checkPermission()

    }

    private fun checkPermission() {
            if (ContextCompat.checkSelfPermission(this,android.Manifest.permission.CAMERA ) == PackageManager.PERMISSION_DENIED ||
                ContextCompat.checkSelfPermission(this,android.Manifest.permission.RECORD_AUDIO ) == PackageManager.PERMISSION_DENIED ||
                ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION ) == PackageManager.PERMISSION_DENIED) {
                // Requesting the permission
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION), 0)
            } else {
                Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show()
            }


    }

    private fun sendRestLink(email:String) {

        if(email != "") {
            Firebase.auth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(
                            baseContext, "Password reset Email sent.",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            baseContext, "Failed",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
        else{
            Toast.makeText(baseContext, "Enter Valid Email Address",
                Toast.LENGTH_SHORT).show()
        }
    }



    private fun registerUser() {
        val i = Intent(this, RegisterActivity::class.java)
        startActivity(i)
    }
    
    private fun signIn(userID: EditText?, pass: EditText?){
        auth = Firebase.auth
        auth.signInWithEmailAndPassword(userID!!.text.toString(),pass!!.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "signInWithEmail:success")
                    val user = auth.currentUser
                    Log.i("USER INFO",user!!.uid)
                    val i = Intent(this, MainActivity::class.java)
                    startActivity(i)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "Authentication failed.",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

}