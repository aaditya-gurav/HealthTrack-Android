package com.asgurav.vdoctor.activities

import android.content.Intent
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.fragments.DashboardFragment
import com.asgurav.vdoctor.fragments.DoctorsFragment
import com.asgurav.vdoctor.fragments.PharmaciesFragment
import com.asgurav.vdoctor.fragments.UserProfileFragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.color.DynamicColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var toolbar: Toolbar
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var userLocation: Location

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        DynamicColors.applyIfAvailable(this)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        initiateFragment()
        initiateNavDrawer()
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigation.itemIconTintList=null

        bottomNavigation.setOnItemSelectedListener { item ->
            when(item.itemId) {
                R.id.dashboard -> {
                    supportFragmentManager.beginTransaction()
                        .setCustomAnimations(R.anim.left_to_right, R.anim.right_to_left)
                        .replace(R.id.fragmentContainer, DashboardFragment())
                        .commit()
                    true
                }
                R.id.doctor_page -> {
                    supportFragmentManager.beginTransaction()
                        .setCustomAnimations(R.anim.left_to_right, R.anim.right_to_left)
                        .replace(R.id.fragmentContainer, DoctorsFragment())
                        .commit()
                    true
                }
                R.id.pharma_page -> {
                    fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
                    fusedLocationClient.lastLocation
                        .addOnSuccessListener { location : Location? ->
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                supportFragmentManager.beginTransaction()
                                    .setCustomAnimations(R.anim.left_to_right, R.anim.right_to_left)
                                    .replace(R.id.fragmentContainer, PharmaciesFragment(location.latitude,location.longitude))
                                    .commit()
                            }
                            else{
                                supportFragmentManager.beginTransaction()
                                    .setCustomAnimations(R.anim.left_to_right, R.anim.right_to_left)
                                    .replace(R.id.fragmentContainer, PharmaciesFragment(37.422244494275354, -122.08415406817522))
                                    .commit()
                            }

                        }
                        .addOnFailureListener { it->
                            Log.i("Excp",it.toString())
                        }

                    true
                }
                R.id.user_profile -> {

                    supportFragmentManager.beginTransaction()
                        .setCustomAnimations(R.anim.left_to_right, R.anim.right_to_left)
                        .replace(R.id.fragmentContainer, UserProfileFragment())
                        .commit()
                    true
                }
                else -> false
            }
        }
        val fab = findViewById<FloatingActionButton>(R.id.fab)

    }

    private fun initiateNavDrawer() {
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val navigation = findViewById<NavigationView>(R.id.navi_drawer)
        val drawer = ActionBarDrawerToggle(this,drawerLayout,toolbar, R.string.open, R.string.close)
        drawer.syncState()
        navigation.setNavigationItemSelectedListener(this)
    }

    private fun initiateFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, DashboardFragment())
            .commit()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.contact -> {
                MaterialAlertDialogBuilder(this,R.style.MyAlertDialogStyle)
                    .setIcon(R.drawable.contact)
                    .setTitle("Contact")
                    .setMessage("Virtual Doctor application is devised as an project for CIS:600 course which gives in depth knowledge of Android Programming.")
                    .setPositiveButton("OK") { dialog, which ->
                        // Respond to neutral button press
                        Log.i("Dialog",dialog.toString()+which.toString())
                    }
                    .show()
                true
            }
            R.id.about_us -> {
                MaterialAlertDialogBuilder(this,R.style.MyAlertDialogStyle)
                    .setIcon(R.drawable.about)
                    .setTitle("About Us")
                    .setMessage("VDr. or Virtual Doctor is a android application solely developed to tend the needs of patients who are unable " +
                            "to get any medical assistance in this pandemic situation. This apps allows user to make appointment's virtual or in person " +
                            "with nearby Doctors. Also it give users, information about nearest pharmacies.")
                    .setPositiveButton("OK") { dialog, which ->
                        // Respond to neutral button press
                        Log.i("Dialog",dialog.toString()+which.toString())
                    }
                    .show()
                true
            }
            R.id.logout -> {
                Firebase.auth.signOut()
                val intent = Intent(this,LoginPage::class.java)
                startActivity(intent)
                true
            }
            else->{
                false
            }
        }
    }
}