package com.asgurav.vdoctor.activities

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.data.UserData
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

class RegisterActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var fullname : com.google.android.material.textfield.TextInputLayout
    private lateinit var phoneNum : com.google.android.material.textfield.TextInputLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val userID = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.r_email)
        val pass = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.r_pass)
        val cPass = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.c_r_pass)

        fullname = findViewById(R.id.r_name)
        phoneNum = findViewById(R.id.r_phone)

        val registerButton = findViewById<Button>(R.id.register)
        val loginButton = findViewById<TextView>(R.id.go_to_login)
        loginButton.setOnClickListener { goLogin() }
        registerButton.setOnClickListener{
           if (userID.editText!!.text.toString() != "" && pass.editText!!.text.toString() != "" &&
               cPass.editText!!.text.toString() != "" && fullname.editText!!.text != null &&
                   phoneNum.editText!!.text != null)
           {
               if (pass.editText!!.text.toString() == cPass.editText!!.text.toString() )
               {
                   register(userID.editText,pass.editText)
               }
               else{
                   cPass.helperText = "Different Password!"
                   MaterialAlertDialogBuilder(this)
                       .setTitle("Password mismatch")
                       .setMessage("Password Not the same")
                       .setPositiveButton("OK") { _, _ ->
                           // Respond to positive button press
                       }
                       .show()
               }
           }
            else
           {
               MaterialAlertDialogBuilder(this)
                   .setTitle("Blank Input Fields")
                   .setMessage("Please fill all the Input fields")
                   .setPositiveButton("OK") { _, _ ->
                       // Respond to positive button press
                   }
                   .show()
           }

        }
    }

    private fun register(userID: EditText?, pass: EditText?) {
        val user = UserData(
            fullname.editText!!.text.toString(),
            userID!!.text.toString(),
            phoneNum.editText!!.text.toString(),
            Calendar.getInstance().time,
            0
        )
        val db = Firebase.firestore
        auth = Firebase.auth
        auth.createUserWithEmailAndPassword(userID.text.toString(),pass!!.text.toString() )
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val logUser = auth.currentUser
                    db.collection("user_data").document(logUser!!.uid)
                        .set(user)
                        .addOnSuccessListener {
                            MaterialAlertDialogBuilder(this)
                                .setTitle("Account Created Successfully !!")
                                .setMessage("Proceed to Login ?")
                                .setPositiveButton("YES") { _, _ ->
                                    goLogin()
                                }
                                .show()
                        }
                        .addOnFailureListener {
                                e -> Log.w(TAG, "Error writing document", e)
                        }
                }
                else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(baseContext, "Network Error.",
                        Toast.LENGTH_SHORT).show()
                }
            }

    }

    private fun goLogin() {
        val i = Intent(this, LoginPage::class.java)
        startActivity(i)
    }
}
