package com.asgurav.vdoctor.fragments

import android.app.Activity.RESULT_OK
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.Editable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.adapters.DoctorAdapter
import com.asgurav.vdoctor.data.AppointmentData
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

class DoctorsFragment : Fragment(),DoctorAdapter.MyItemClickListener {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter : DoctorAdapter
    private lateinit var queryData : QuerySnapshot
    private lateinit var searchText : EditText
    private lateinit var activityResultLauncher : ActivityResultLauncher<Intent>
    private var userId = Firebase.auth.currentUser?.uid
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?  {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_doctors, container, false)
        searchText = view.findViewById(R.id.docName)
        // voice to text
        val mic = view.findViewById<ImageView>(R.id.mic)
        mic.setOnClickListener {
            speak()
        }
        //search button func
        val search = view.findViewById<ImageView>(R.id.search)
        search.setOnClickListener{
            searchDoctor(searchText.text.toString())
        }
        //activity launcher
        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            result: ActivityResult? ->
            if(result!!.resultCode == RESULT_OK && result.data != null)
            {
                val speechText = result.data!!.getStringArrayListExtra(
                    RecognizerIntent.EXTRA_RESULTS
                ) as ArrayList<*>
                searchText.text = speechText[0] as Editable?
            }
        }

        getDoctorList(view)
        return view
    }

    private fun speak() {
        val mIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())
        mIntent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak the doctor Specialization !!")
        try {
            activityResultLauncher.launch(mIntent)
        }
        catch (e:Exception){
            Log.i("Exc",e.toString())
        }
    }

    private fun searchDoctor(text: String) {
        val index = adapter.findFirst(text)
        if (index>0){
            recyclerView.smoothScrollToPosition(index)
            Toast.makeText(context,"Found",Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(context,"Please modify your search !!",Toast.LENGTH_SHORT).show()
        }
    }

    private fun getDoctorList(view: View) {
        val db = Firebase.firestore
        db.collection("doctors").get()
            .addOnSuccessListener { result ->
                queryData = result
                recyclerView = view.findViewById(R.id.doctor_recycler)
                recyclerView.layoutManager = GridLayoutManager(context,2)
                adapter = DoctorAdapter(queryData.documents)
                adapter.setMyItemClickListener(this)
                recyclerView.adapter = adapter
            }
            .addOnFailureListener {
                Log.w("ERROR", "Error getting documents.", it)
            }

    }

    override fun onBookButtonClicked(view: View, position: Int, doctorInfo: DocumentSnapshot) {
        val singleItems = arrayOf("10:00 AM - 11:00 AM", "11:00 AM - 12:00 PM", "12:00 PM - 01:00 PM","01:00 PM - 02:00 PM",
            "02:00 PM - 03:00 PM","03:00 PM - 04:00 PM","04:00 PM - 05:00 PM","05:00 PM - 06:00 PM")
        var checkedItem = 0
        context?.let {
            MaterialAlertDialogBuilder(it)
                .setTitle(resources.getString(R.string.book_appointment))
                .setNeutralButton(resources.getString(R.string.cancel)) { _, _ ->
                    // Respond to neutral button press
                }
                .setPositiveButton("Confirm") { _, _ ->
                    // Respond to positive button press
                   bookAppointment(singleItems[checkedItem],doctorInfo)
                }
                // Single-choice items (initialized with checked item)
                .setSingleChoiceItems(singleItems, checkedItem) {dialog, which ->
                    // Respond to item chosen
                    checkedItem = which
                    Toast.makeText(context,checkedItem.toString(),Toast.LENGTH_SHORT).show()
                }
                .show()
        }
    }

    private fun bookAppointment(time: String, doctorInfo: DocumentSnapshot?) {

        val appointment = AppointmentData(
            doctorInfo?.id,
            "https://meet.google.com/vzd-bijg-xay",
            time,
            userId,
            Calendar.getInstance().time
        )

        val db = Firebase.firestore
        db.collection("appointment_data")
            .document()
            .set(appointment)
            .addOnSuccessListener {
                Log.d(ContentValues.TAG, "DocumentSnapshot successfully added!")
            }
            .addOnFailureListener {
                    e -> Log.w(ContentValues.TAG, "Error writing document", e)
            }
    }

}