package com.asgurav.vdoctor.fragments

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.adapters.NewsAdapter
import com.asgurav.vdoctor.data.Article
import com.asgurav.vdoctor.data.NewsData
import com.asgurav.vdoctor.data.RetrNews
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import android.content.Intent
import android.net.Uri
import android.widget.TextView
import android.widget.Toast
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.activities.MainActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso


class DashboardFragment : Fragment(),NewsAdapter.GoButtonClicked{
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter : NewsAdapter
    private lateinit var newsList: List<Article>
    private val baseURL:String ="https://newsapi.org/"
    private val storageRef = FirebaseStorage.getInstance().reference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_dashboard, container, false)
        createCard(view)
        createNews(view)
        return view
    }

    private fun createCard(view: View?) {

        val db = Firebase.firestore
        db.collection("appointment_data")
            .whereEqualTo("user_id",Firebase.auth.currentUser?.uid)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty){
                    val card = view?.findViewById<com.google.android.material.card.MaterialCardView>(R.id.appointment_card)
                    val topTitle = view?.findViewById<TextView>(R.id.cardTopTitle)
                    val viewBottom = view?.findViewById<View>(R.id.cardBottomView)
                    card?.visibility = View.GONE
                    topTitle?.visibility = View.GONE
                    viewBottom?.visibility = View.GONE
                }
                else{
                    val docId = documents.first()["doc_id"].toString()
                    db.collection("doctors")
                        .document(docId)
                        .get()
                        .addOnSuccessListener { result ->
                            makeCard(view,result,documents)
                        }
                        .addOnFailureListener { exception ->
                            Log.w("ERROR", "Error getting documents.", exception)
                        }

                }
            }
            .addOnFailureListener { exception ->
                Log.i("Data", "Error getting documents: ", exception)
            }


    }

    private fun makeCard(view: View?, result: DocumentSnapshot?, documents: QuerySnapshot) {
        if (view != null) {
            view.findViewById<TextView>(R.id.docTitleCard).text = result!!["doctor_name"] as CharSequence?
            ("Time:"+documents.first()["time"] as CharSequence?).also { view.findViewById<TextView>(R.id.docTimeCard).text = it }

            //Image is set
            val image = view.findViewById<com.mikhaellopez.circularimageview.CircularImageView>(R.id.docImageCard)
            storageRef.child("doctor_images/"+result["doctor_image"].toString()).downloadUrl.addOnSuccessListener {
                val url = it
                Picasso.get().load(url).into(image)
            }.addOnFailureListener {
                Log.i("ERRoR","Image URL NOT FOUND")
            }

            //Buttons are made functional
            val canButton = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.cancelAppt)
            canButton.setOnClickListener {
                context?.let { it1 ->
                    MaterialAlertDialogBuilder(it1)
                        .setTitle("Cancel Appointment")
                        .setMessage("Are you sure you want to cancel your appointment ?")
                        .setNeutralButton("Dismiss") { _, _ ->
                            // Respond to neutral button press
                        }
                        .setPositiveButton("Confirm") { _, _ ->
                            // Respond to positive button press
                            val id = documents.first().id
                            Log.d(TAG, id)
                            val db = Firebase.firestore
                            db.collection("appointment_data").document(id)
                                .delete()
                                .addOnSuccessListener {
                                    Log.d(TAG, "DocumentSnapshot successfully deleted!")
                                    val intent = Intent(context, MainActivity::class.java)
                                    startActivity(intent)
                                     }
                                .addOnFailureListener { e -> Log.w(TAG, "Error deleting document", e) }
                        }
                        .show()
                }
            }

            val linkButton = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.openAppt)
            linkButton.setOnClickListener {
                val uri: Uri = Uri.parse(documents.first()["link"] as String?) // missing 'http://' will cause crashed
                val intent = Intent(Intent.ACTION_VIEW, uri)
                startActivity(intent)
            }
        }
    }

    private fun createNews(view: View?) {
        val retrofit = Retrofit.Builder()
                        .baseUrl(baseURL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build()
        val service = retrofit.create(RetrNews::class.java)
        val call = service.getNewsData("us","health","af5888d567094fb88a0e53a8bd1227c5")
        call.enqueue((object : Callback<NewsData>{
            override fun onResponse(call: Call<NewsData>, response: Response<NewsData>) {
                newsList = response.body()!!.articles
                createRecyclerView(newsList,view)
            }
            override fun onFailure(call: Call<NewsData>, t: Throwable) {
                Log.i("Error","Error")
            }

        }))
    }

    private fun createRecyclerView(newsList: List<Article>,view: View?) {
        if (view != null) {
            recyclerView = view.findViewById(R.id.dashboard_recycler)
        }
        adapter = NewsAdapter(newsList)
        adapter.setMyItemClickListener(this)
        recyclerView.adapter = adapter
    }

    override fun onGoButton(position: Int) {
        val uri: Uri = Uri.parse(newsList[position].url) // missing 'http://' will cause crashed
        val intent = Intent(Intent.ACTION_VIEW, uri)
        startActivity(intent)
    }

}