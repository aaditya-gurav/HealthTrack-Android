package com.asgurav.vdoctor.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AppointmentAdapter(private var documents: MutableList<DocumentSnapshot>) : RecyclerView.Adapter<AppointmentAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val docName: TextView = itemView.findViewById(R.id.doc_name)
        val aptTime: TextView = itemView.findViewById(R.id.apt_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.fragment_appointment_tile,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = documents[position]
        holder.aptTime.text = item["time"].toString()

        val docId = item["doc_id"].toString()
        val db = Firebase.firestore
        db.collection("doctors")
            .document(docId)
            .get()
            .addOnSuccessListener {
                holder.docName.text = it["doctor_name"].toString()
            }
            .addOnFailureListener { exception ->
                Log.w("ERROR", "Error getting documents.", exception)
            }
    }

    override fun getItemCount(): Int {
        return documents.size
    }
}