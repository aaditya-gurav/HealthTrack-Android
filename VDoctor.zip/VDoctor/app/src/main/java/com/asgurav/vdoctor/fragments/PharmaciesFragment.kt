package com.asgurav.vdoctor.fragments


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.asgurav.vdoctor.R
import com.asgurav.vdoctor.adapters.PharmacyAdapter
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PharmaciesFragment(var latitude: Double, var longitude: Double) : Fragment(),PharmacyAdapter.MyItemClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter : PharmacyAdapter
    private lateinit var queryData : QuerySnapshot
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_pharmacies, container, false)
        //Toast.makeText(context,userLocation.latitude.toString() + userLocation.longitude.toString(),Toast.LENGTH_SHORT).show()
        createPharmacyTiles(view)
        return view
    }

    private fun createPharmacyTiles(view: View) {
        val db = Firebase.firestore
        db.collection("pharma_data")
            .get()
            .addOnSuccessListener {
                queryData = it
                recyclerView = view.findViewById(R.id.pharmacy_recycler)
                recyclerView.layoutManager = LinearLayoutManager(context)
                adapter = PharmacyAdapter(queryData.documents)
                adapter.setMyItemClickListener(this)
                recyclerView.adapter = adapter
            }
            .addOnFailureListener {
                Log.w("ERROR", "Error getting documents.", it)
            }

    }

    override fun onGetDirection(view: View, position: Int, doctorInfo: DocumentSnapshot) {
        val url = "https://www.google.com/maps/dir/?api=1&" +
                "origin=${latitude}, ${longitude}&" +
                "destination=${doctorInfo["latitude"]}, ${doctorInfo["longitude"]}" 

        val uri: Uri = Uri.parse(url) // missing 'http://' will cause crashed
        val intent = Intent(Intent.ACTION_VIEW, uri)
        startActivity(intent)
        //Toast.makeText(context,"This is clicked",Toast.LENGTH_SHORT).show()
    }


}